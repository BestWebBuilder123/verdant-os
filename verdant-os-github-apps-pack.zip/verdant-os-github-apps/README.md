# Verdant OS — GitHub Apps Pack

Includes `verdant-os.html` and an `apps/` folder with 20 standalone HTML apps plus `manifest.json`. Verdant OS fetches the manifest and app HTML from GitHub, then opens each app in a sandboxed iframe.

## Install
1. Upload `verdant-os.html` to the root of your existing `BestWebBuilder123/verdant-os` repository (or merge it into your current OS file).
2. Upload the complete `apps/` folder into the repository root.
3. Commit to `main`.
4. The configured URL is `https://raw.githubusercontent.com/BestWebBuilder123/verdant-os/main/apps`. If your owner/repo/branch differs, change `GITHUB_APPS_BASE` in `verdant-os.html` to `https://raw.githubusercontent.com/OWNER/REPO/BRANCH/apps`.

## Add an app
Create a self-contained `apps/my-app.html` file and add an entry to `apps/manifest.json`: `{ "id":"my-app", "name":"My App", "icon":"✦", "description":"What it does", "file":"my-app.html" }`. Commit the change.

## Notes
- Requires internet access and a public repository for raw GitHub fetches. If fetch fails, Verdant OS falls back to its built-in app version.
- App iframes are sandboxed with scripts/forms/modals/popups enabled, but do not get unrestricted parent access.
- A small `postMessage` bridge supports local JSON storage, app launching, app installs, task manager window lists, and settings. This is browser-local, not cloud sync.
- Apps are public HTML; do not store secrets or private data in the repository.
